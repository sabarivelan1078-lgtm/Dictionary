package com.example.bilingualdictionary.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "words_cache")
data class WordEntity(
    @PrimaryKey val word: String,
    val ipa: String?,
    val meaningsJson: String, 
    val tamilMeaning: String?,
    val tamilExample: String?,
    val cefr: String?, 
    val frequency: String?, 
    val syllables: String?, 
    val etymology: String?,
    val collocations: String?, 
    val lookupCount: Int = 1,
    val timestamp: Long = System.currentTimeMillis()
)