package com.example.bilingualdictionary.service

import android.accessibilityservice.AccessibilityService
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class DictionaryAccessibilityService : AccessibilityService() {

    private var lastExtractedText = ""
    private var clipboardManager: ClipboardManager? = null

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val clipData = clipboardManager?.primaryClip
        if (clipData != null && clipData.itemCount > 0) {
            val text = clipData.getItemAt(0).text?.toString()?.trim() ?: ""
            if (text.isNotEmpty() && text != lastExtractedText && text.split("\\s+".toRegex()).size <= 3) {
                lastExtractedText = text
                showOverlayService(text)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboardManager?.addPrimaryClipChangedListener(clipListener)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED) {
            val node = event.source ?: return
            val start = event.fromIndex
            val end = event.toIndex
            if (start != -1 && end != -1 && start != end) {
                val text = event.text.joinToString(" ")
                val selectedSubText = try {
                    text.substring(start, end).trim()
                } catch (e: Exception) {
                    ""
                }
                if (selectedSubText.isNotEmpty() && selectedSubText.split("\\s+".toRegex()).size <= 3) {
                    showOverlayService(selectedSubText)
                }
            }
        }
    }

    private fun showOverlayService(word: String) {
        val intent = Intent(this, OverlayWindowManager::class.java).apply {
            putExtra("EXTRA_WORD", word)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                OverlayWindowManager.showPopup(this, word)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        clipboardManager?.removePrimaryClipChangedListener(clipListener)
    }
}