package com.example.bilingualdictionary.service

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.ImageButton
import android.widget.Button
import android.speech.tts.TextToSpeech
import android.widget.Toast
import com.example.bilingualdictionary.R
import java.util.Locale

object OverlayWindowManager {
    private var windowManager: WindowManager? = null
    private var popupView: View? = null
    private var tts: TextToSpeech? = null

    fun showPopup(context: Context, word: String) {
        dismiss()

        windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val layoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        popupView = layoutInflater.inflate(R.layout.layout_floating_popup, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = 0
            y = 150
            width = context.resources.displayMetrics.widthPixels.coerceAtMost(1024)
        }

        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
            }
        }

        val wordTitle = popupView?.findViewById<TextView>(R.id.tv_word_title)
        val meaningEn = popupView?.findViewById<TextView>(R.id.tv_meaning_en)
        val meaningTa = popupView?.findViewById<TextView>(R.id.tv_meaning_ta)
        val btnAudioUs = popupView?.findViewById<ImageButton>(R.id.btn_audio_us)
        val btnAudioUk = popupView?.findViewById<ImageButton>(R.id.btn_audio_uk)
        val btnFullEntry = popupView?.findViewById<Button>(R.id.btn_full_entry)
        val btnClose = popupView?.findViewById<ImageButton>(R.id.btn_close_popup)

        wordTitle?.text = word
        meaningEn?.text = "Fetching pronunciation and definitions..."
        meaningTa?.text = "தமிழ் மொழிபெயர்ப்பு பெறப்படுகிறது..."

        btnAudioUs?.setOnClickListener {
            tts?.setPitch(1.05f)
            tts?.setSpeechRate(0.88f)
            tts?.speak(word, TextToSpeech.QUEUE_FLUSH, null, "US")
        }

        btnAudioUk?.setOnClickListener {
            tts?.setPitch(1.0f)
            tts?.setSpeechRate(0.85f)
            tts?.speak(word, TextToSpeech.QUEUE_FLUSH, null, "UK")
        }

        btnFullEntry?.setOnClickListener {
            val appIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
                putExtra("LAUNCH_WORD", word)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (appIntent != null) {
                context.startActivity(appIntent)
            }
            dismiss()
        }

        btnClose?.setOnClickListener { dismiss() }

        popupView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialY = 0f
            private var startY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialY = params.y.toFloat()
                        startY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val diffY = event.rawY - startY
                        if (diffY > 100) {
                            dismiss()
                            return true
                        }
                        params.y = (initialY + diffY).toInt()
                        windowManager?.updateViewLayout(popupView, params)
                        return true
                    }
                }
                return false
            }
        })

        windowManager?.addView(popupView, params)
    }

    fun dismiss() {
        try {
            if (popupView != null && windowManager != null) {
                windowManager?.removeView(popupView)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            popupView = null
            windowManager = null
            tts?.stop()
            tts?.shutdown()
            tts = null
        }
    }
}